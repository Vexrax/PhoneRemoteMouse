var WebSocketClient = require('websocket').client;
var client = new WebSocketClient();
var tunnel = require('tunnel');

// var tunnelingAgent = tunnel.httpOverHttp({
//   proxy: {
//     host: 'proxy.host.com',
//     port: 8080
//   }
// });

// var requestOptions = {
//     agent: tunnelingAgent
// };

client.connect('http://localhost:5000', null, ["lmao", {name: 'test'}], null, null);