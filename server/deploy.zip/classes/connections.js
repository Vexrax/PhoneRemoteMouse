class connections {
    constructor(eventEmitter) {
        // key is mobile ip address
        this.connecs = {}

        // key is user id
        this.unassignedMobiles = {}

        // key is user id
        this.unassignedComputers = {}

        this.connections = require('./connection');

        this.emitter = eventEmitter;
    }
    
    addMobile(mobileConnection) {
        // This user has connected a computer already
        if(this.unassignedComputers[mobileConnection.name]) {
            // Move connections to completed and create a new connection object
            this.connecs[mobileConnection.ipAddress] = new this.connections(mobileConnection, this.unassignedComputers[mobileConnection.name], mobileConnection.id);
            // Remove old connection
            delete this.unassignedComputers[mobileConnection.name];
            console.log("New Pair Added");
            this.emitter.emit('connectionMade', this.connecs[mobileConnection.ipAddress])
        }
        // This user has not connected a computer yet
        else {
            // Move connections to completed and create a new connection object
            this.unassignedMobiles[mobileConnection.name] = mobileConnection;
            console.log("Unassigned Mobile Added");
        }
    }

    addComputer(computerConnection) {
        // User has connected a mobile connection already
        if(this.unassignedMobiles[computerConnection.name]) {
            var mobileConnection = this.unassignedMobiles[computerConnection.name];
            // move connections to completed
            this.connecs[mobileConnection.ipAddress] = new this.connections(mobileConnection, computerConnection, computerConnection.id);;
            // Remove old connection
            delete this.unassignedMobiles[computerConnection.name];
            console.log("New Pair Added");
            this.emitter.emit('connectionMade', this.connecs[mobileConnection.ipAddress])

        }
        // User doesn't have a mobile connection yet
        else {
            this.unassignedComputers[computerConnection.name] = computerConnection;
            console.log("Unassigned Computer Added");
        }
    }

    //should get a connection with the ip address of a mobile connection
    getConnection(address) {
        return this.connecs[address];
    }
}

module.exports = connections;